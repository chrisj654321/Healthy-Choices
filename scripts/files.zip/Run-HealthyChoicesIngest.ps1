# Run-HealthyChoicesIngest.ps1
# Runs the 5 HealthyChoices ingest commands in order.
# Stops and logs the error if any command fails (including EAI_AGAIN / HTTP 503).

$WorkingDir = "C:\Users\chris\HealthyChoices"
$LogFile    = "$WorkingDir\scripts\ingestion_log.txt"

# ── Helpers ──────────────────────────────────────────────────────────────────

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [$Level] $Message"
    Write-Host $line
    Add-Content -Path $LogFile -Value $line
}

function Invoke-IngestCommand {
    param([string]$Arguments)

    Write-Log "Running: node $Arguments"

    # Capture stdout + stderr together so network errors are visible
    $output = & node $Arguments 2>&1 | Out-String

    $exitCode = $LASTEXITCODE

    # Surface the output regardless of success/failure
    if ($output.Trim()) {
        foreach ($outputLine in ($output -split "`n")) {
            $trimmed = $outputLine.TrimEnd()
            if ($trimmed) { Write-Log "  $trimmed" }
        }
    }

    # Treat non-zero exit OR known transient error strings as failure
    $isNetworkError = ($output -match "EAI_AGAIN" -or $output -match "HTTP 503" -or $output -match "ECONNREFUSED")

    if ($exitCode -ne 0 -or $isNetworkError) {
        $reason = if ($isNetworkError) { "network error detected in output" } else { "exit code $exitCode" }
        Write-Log "FAILED ($reason) — stopping pipeline." "ERROR"
        return $false
    }

    Write-Log "Completed successfully (exit code 0)."
    return $true
}

# ── Main ─────────────────────────────────────────────────────────────────────

Set-Location $WorkingDir

Write-Log "========================================================"
Write-Log "healthy-choices-daily-ingest  START"
Write-Log "Working directory: $WorkingDir"

$commands = @(
    'scripts/ingest-products.js --batch=25 --query="protein bar"',
    'scripts/ingest-products.js --batch=25 --query="organic snack"',
    'scripts/ingest-products.js --batch=25 --query="cereal"',
    'scripts/ingest-products.js --batch=25 --query="energy drink"',
    'scripts/ingest-products.js --batch=25 --source=usda --query="granola"'
)

$stepNumber = 1
$allOk      = $true

foreach ($cmd in $commands) {
    Write-Log "--- Step $stepNumber of $($commands.Count) ---"
    $ok = Invoke-IngestCommand -Arguments $cmd
    if (-not $ok) {
        $allOk = $false
        break
    }
    $stepNumber++
}

if ($allOk) {
    Write-Log "healthy-choices-daily-ingest  COMPLETED (all steps passed)"
} else {
    Write-Log "healthy-choices-daily-ingest  ABORTED (see ERROR above)" "ERROR"
    exit 1
}

Write-Log "========================================================"
